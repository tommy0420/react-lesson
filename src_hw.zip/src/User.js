import React from 'react'
import List from './List'

const User = () => {
  return (
    <>
      <h2></h2>
      <List />
    </>
  )
}

export default User