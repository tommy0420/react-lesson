import React from 'react'

const List = () => {
  return (
    <ul>
      <li></li>
      <li></li>
    </ul>
  )
}


export default List