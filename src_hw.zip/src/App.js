import React from 'react'
import User from './User'

const App = () => {
  return (
    <div>
      <h1>hello world</h1>
      <p>react始めます</p>
      <User />
      <User />
    </div>
  )
}

export default App